function VapiAssistant({ company, onBack }) {
    try {
        const [isCallActive, setIsCallActive] = React.useState(false);
        const [callTranscript, setCallTranscript] = React.useState([]);
        const [currentSpeaker, setCurrentSpeaker] = React.useState('');
        const [currentText, setCurrentText] = React.useState('');
        const [showDownloadModal, setShowDownloadModal] = React.useState(false);

        React.useEffect(() => {
            lucide.createIcons();
            
            const script = document.createElement('script');
            script.src = "https://cdn.jsdelivr.net/gh/VapiAI/html-script-tag@latest/dist/assets/index.js";
            script.defer = true;
            script.async = true;
            
            script.onload = function() {
                if (window.vapiSDK) {
                    const assistant = "67faffbf-303c-4521-b414-271e3e937b6d";
                    const apiKey = "2526f8cb-963b-4e1a-a9ff-bcbe2eb31dd1";
                    
                    const buttonConfig = {
                        position: "right",
                        style: "default",
                        text: "🎙 Talk to Grace AI"
                    };
                    
                    window.vapiInstance = window.vapiSDK.run({
                        apiKey: apiKey,
                        assistant: assistant,
                        config: buttonConfig
                    });

                    if (window.vapiInstance) {
                        window.vapiInstance.on('call-start', () => {
                            setIsCallActive(true);
                            setCallTranscript([]);
                            addParagraph('system', 'Call started - Grace AI is now listening and recording...');
                        });

                        window.vapiInstance.on('message', (message) => {
                            if (message.type === 'transcript' && message.transcript) {
                                const role = message.role === 'assistant' ? 'assistant' : 'user';
                                updateCurrentText(role, message.transcript);
                            }
                        });

                        window.vapiInstance.on('speech-start', (event) => {
                            const role = event.role === 'assistant' ? 'assistant' : 'user';
                            startNewSpeech(role);
                        });

                        window.vapiInstance.on('speech-end', (event) => {
                            if (event.transcript && currentText) {
                                finalizeSpeech(event.transcript);
                            }
                        });

                        window.vapiInstance.on('call-end', () => {
                            setIsCallActive(false);
                            addParagraph('system', 'Call ended - Processing complete conversation and recording...');
                            setTimeout(() => setShowDownloadModal(true), 2000);
                        });
                    }
                }
            };
            
            document.head.appendChild(script);
            
            return () => {
                if (window.vapiInstance) {
                    window.vapiInstance.destroy?.();
                }
                if (script.parentNode) {
                    script.parentNode.removeChild(script);
                }
            };
        }, []);

        const startNewSpeech = (role) => {
            if (currentText && currentSpeaker) {
                addParagraph(currentSpeaker, currentText);
            }
            setCurrentSpeaker(role);
            setCurrentText('');
        };

        const updateCurrentText = (role, text) => {
            if (role === currentSpeaker) {
                setCurrentText(text);
            }
        };

        const finalizeSpeech = (finalText) => {
            if (currentSpeaker && finalText) {
                addParagraph(currentSpeaker, finalText);
                setCurrentText('');
                setCurrentSpeaker('');
            }
        };

        const addParagraph = (role, text) => {
            const timestamp = new Date().toLocaleTimeString();
            setCallTranscript(prev => [...prev, { role, text, timestamp }]);
        };

        const generatePDF = () => {
            const pdfContent = `
ABC BANK LOAN CONSULTATION - COMPLETE CALL RECORD
================================================================

Company: ${company.name}
Date: ${new Date().toLocaleDateString()}
Time: ${new Date().toLocaleTimeString()}
Call Duration: ${callTranscript.length > 2 ? 'Complete Session' : 'Brief Call'}

CONVERSATION TRANSCRIPT:
================================================================

${callTranscript.map(entry => {
    const speaker = entry.role === 'assistant' ? 'GRACE AI ASSISTANT' : 
                   entry.role === 'user' ? 'CUSTOMER' : 'SYSTEM';
    return `[${entry.timestamp}] ${speaker}:\n${entry.text}\n`;
}).join('\n')}

================================================================

CALL RECORDING INFORMATION:
- Audio Quality: High Definition
- Recording Format: MP3
- File Status: Successfully Recorded
- Transcription: Real-time AI Processing
- Storage: Secure Cloud Storage

SUMMARY:
This document contains the complete conversation transcript and recording information for the customer consultation with Grace AI assistant regarding ${company.name} loan services. All conversations are recorded and transcribed for quality assurance and customer service improvement.

Generated by ConnectmeAI - Grace AI Assistant Platform
Customer Service & Call Recording System
================================================================
            `;
            
            const blob = new Blob([pdfContent], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ABC_Bank_Complete_Call_Record_${new Date().getTime()}.txt`;
            a.click();
            URL.revokeObjectURL(url);
        };

        return (
            <div data-name="vapi-assistant" data-file="components/VapiAssistant.js" className="min-h-screen pt-24 pb-16">
                <div className="container mx-auto px-6">
                    <div className="flex items-center mb-8">
                        <button 
                            onClick={onBack}
                            className="flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors"
                        >
                            <i data-lucide="arrow-left" className="w-5 h-5"></i>
                            Back to {company.name}
                        </button>
                    </div>

                    <div className="grid lg:grid-cols-2 gap-8">
                        <div>
                            <div className="glass-effect rounded-2xl p-8 mb-6">
                                <div className="w-24 h-24 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full mx-auto mb-6 flex items-center justify-center">
                                    <i data-lucide="mic" className="w-12 h-12 text-white"></i>
                                </div>
                                
                                <h1 className="text-3xl font-bold mb-3 text-center">Welcome to ABC Bank</h1>
                                <h2 className="text-xl font-semibold mb-4 gradient-text text-center">Personal Loan Assistant</h2>
                                
                                <p className="text-lg text-gray-300 mb-6 text-center">
                                    Talk to our voice assistant Grace about loans 👇
                                </p>
                                
                                <div className="text-center">
                                    <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${
                                        isCallActive ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'
                                    }`}>
                                        <div className={`w-2 h-2 rounded-full ${
                                            isCallActive ? 'bg-red-400 animate-pulse' : 'bg-green-400'
                                        }`}></div>
                                        <span className="text-sm font-semibold">
                                            {isCallActive ? 'Recording & Transcribing' : 'Grace AI Ready'}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div className="glass-effect rounded-2xl p-6 h-[600px] flex flex-col">
                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="text-xl font-semibold">Live Conversation</h3>
                                    {isCallActive && (
                                        <div className="flex items-center gap-2 text-red-400">
                                            <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                                            <span className="text-sm">Recording</span>
                                        </div>
                                    )}
                                </div>
                                
                                <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                                    {callTranscript.length === 0 ? (
                                        <div className="text-center text-gray-400 py-8">
                                            <i data-lucide="mic-off" className="w-12 h-12 mx-auto mb-3 opacity-50"></i>
                                            <p>Start a call to see conversation</p>
                                        </div>
                                    ) : (
                                        callTranscript.map((entry, index) => (
                                            <div key={index} className={`p-4 rounded-lg ${
                                                entry.role === 'user' ? 'bg-blue-500/20' :
                                                entry.role === 'assistant' ? 'bg-purple-500/20' :
                                                'bg-gray-500/20'
                                            }`}>
                                                <div className="flex justify-between items-start mb-2">
                                                    <span className="text-sm font-semibold">
                                                        {entry.role === 'assistant' ? 'Grace AI' : 
                                                         entry.role === 'user' ? 'Customer' : 'System'}
                                                    </span>
                                                    <span className="text-xs text-gray-400">{entry.timestamp}</span>
                                                </div>
                                                <p className="text-sm leading-relaxed">{entry.text}</p>
                                            </div>
                                        ))
                                    )}
                                    
                                    {currentText && (
                                        <div className={`p-4 rounded-lg border-2 border-dashed ${
                                            currentSpeaker === 'user' ? 'border-blue-400 bg-blue-500/10' :
                                            'border-purple-400 bg-purple-500/10'
                                        }`}>
                                            <div className="text-sm font-semibold mb-2">
                                                {currentSpeaker === 'assistant' ? 'Grace AI' : 'Customer'} (Speaking...)
                                            </div>
                                            <p className="text-sm leading-relaxed">{currentText}</p>
                                        </div>
                                    )}
                                </div>
                                
                                {callTranscript.length > 0 && !isCallActive && (
                                    <button 
                                        onClick={generatePDF}
                                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg hover:shadow-lg transition-all"
                                    >
                                        <i data-lucide="download" className="w-5 h-5 inline mr-2"></i>
                                        Download Call Record & Transcript
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>

                    {showDownloadModal && (
                        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                            <div className="bg-gray-800 rounded-xl p-8 max-w-md w-full mx-4">
                                <div className="text-center">
                                    <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                                        <i data-lucide="check" className="w-8 h-8 text-white"></i>
                                    </div>
                                    <h3 className="text-2xl font-bold mb-4">Call Completed!</h3>
                                    <p className="text-gray-300 mb-6">Your conversation and recording are ready for download.</p>
                                    
                                    <button 
                                        onClick={generatePDF}
                                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg hover:shadow-lg transition-all mb-4"
                                    >
                                        <i data-lucide="file-text" className="w-4 h-4 inline mr-2"></i>
                                        Download Complete Record
                                    </button>
                                    
                                    <button 
                                        onClick={() => setShowDownloadModal(false)}
                                        className="text-gray-400 hover:text-white transition-colors"
                                    >
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    } catch (error) {
        console.error('VapiAssistant component error:', error);
        reportError(error);
    }
}
